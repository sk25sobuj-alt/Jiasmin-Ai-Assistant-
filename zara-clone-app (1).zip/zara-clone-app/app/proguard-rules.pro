# Add project-specific ProGuard rules here. Minification is currently disabled
# (minifyEnabled false), so this file is a placeholder.
