package com.example.aiassistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsFragment : Fragment() {

    companion object {
        val PERSONALITIES = listOf(
            "GirlFriend", "Boss", "Teacher", "Soft Romantic Listener",
            "Hyper Energetic", "Caring Neon AI", "Savage Girl", "Mystical",
            "Unknown", "Manipulative", "MT Assistant", "Custom"
        )
        const val DEFAULT_PERSONALITY = "MT Assistant"

        // Gemini cloud TTS voices + device fallback
        val VOICES = listOf(
            "Phone Default (Device TTS)",
            "Kore", "Achernar", "Aoede", "Autonoe", "Callirrhoe", "Despina",
            "Erinome", "Gacrux", "Laomedeia", "Leda", "Pulcherrima",
            "Puck", "Charon", "Fenrir"
        )
        const val DEFAULT_VOICE = "Kore"
        const val DEVICE_VOICE = "Phone Default (Device TTS)"

        val LANGUAGES = listOf(
            "Hinglish", "English", "Hindi", "Bengali", "Telugu", "Rajasthani",
            "Marathi", "Tamil", "Urdu", "Gujarati", "Kannada", "Malayalam",
            "Odia", "Punjabi", "Arabic", "French", "German", "Spanish",
            "Portuguese", "Russian", "Chinese (Simplified)", "Japanese", "Korean",
            "Turkish", "Vietnamese", "Thai", "Indonesian", "Italian", "Dutch",
            "Persian"
        )
        const val DEFAULT_LANGUAGE = "Bengali"
        const val ALL_LANGUAGES = "🌐 All Languages (Auto)"

        // Avatar emoji choices for the AI
        val AVATARS = listOf("🤖", "👩", "🧑‍🚀", "🐱", "🦊", "🐼", "👾", "💜")
        const val DEFAULT_AVATAR = "🤖"
    }

    private val prefs by lazy {
        requireContext().getSharedPreferences("ai_assistant_prefs", Context.MODE_PRIVATE)
    }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            refreshPermBadges()
        }

    private val requestMultipleLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            refreshPermBadges()
        }

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                prefs.edit().putBoolean("screen_capture_granted", true).apply()
            }
            refreshPermBadges()
        }

    private data class PermRow(
        val titleRes: Int,
        val descRes: Int,
        val check: () -> Boolean,
        val action: () -> Unit,
        val badgeOverride: String? = null
    )

    private data class PermRowView(val row: PermRow, val badge: TextView)

    private val permRowViews = mutableListOf<PermRowView>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_settings, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        // ---- API keys ----
        val editGeminiKey = view.findViewById<EditText>(R.id.editGeminiKey)
        val editOpenRouterKey = view.findViewById<EditText>(R.id.editOpenRouterKey)
        val editModel = view.findViewById<EditText>(R.id.editModel)
        val editSerpKey = view.findViewById<EditText>(R.id.editSerpKey)
        editGeminiKey.setText(prefs.getString("gemini_key", "").orEmpty())
        editOpenRouterKey.setText(prefs.getString("openrouter_key", "").orEmpty())
        editModel.setText(prefs.getString("or_model", "openai/gpt-4o-mini").orEmpty())
        editSerpKey.setText(prefs.getString("serp_key", "").orEmpty())

        view.findViewById<Button>(R.id.btnSaveGeminiKey).setOnClickListener {
            prefs.edit().putString("gemini_key", editGeminiKey.text.toString().trim()).apply()
            toastSaved()
        }
        view.findViewById<Button>(R.id.btnSaveOpenRouterKey).setOnClickListener {
            prefs.edit().putString("openrouter_key", editOpenRouterKey.text.toString().trim()).apply()
            toastSaved()
        }
        view.findViewById<Button>(R.id.btnSaveModel).setOnClickListener {
            prefs.edit().putString("or_model", editModel.text.toString().trim()).apply()
            toastSaved()
        }
        view.findViewById<Button>(R.id.btnSaveSerpKey).setOnClickListener {
            prefs.edit().putString("serp_key", editSerpKey.text.toString().trim()).apply()
            toastSaved()
        }

        // ---- Provider selector ----
        val radioProvider = view.findViewById<RadioGroup>(R.id.radioProvider)
        if (prefs.getString("llm_provider", "gemini") == "openrouter") {
            view.findViewById<RadioButton>(R.id.radioOpenRouter).isChecked = true
        } else {
            view.findViewById<RadioButton>(R.id.radioGemini).isChecked = true
        }
        var updatingProvider = false
        radioProvider.setOnCheckedChangeListener { _, checkedId ->
            if (updatingProvider) return@setOnCheckedChangeListener
            if (checkedId == R.id.radioOpenRouter && !prefs.getBoolean("openrouter_enabled", true)) {
                Toast.makeText(
                    requireContext(),
                    getString(R.string.api_unavailable, "OpenRouter"),
                    Toast.LENGTH_LONG
                ).show()
                updatingProvider = true
                view.findViewById<RadioButton>(R.id.radioGemini).isChecked = true
                updatingProvider = false
                return@setOnCheckedChangeListener
            }
            prefs.edit()
                .putString("llm_provider", if (checkedId == R.id.radioOpenRouter) "openrouter" else "gemini")
                .apply()
        }

        // ---- API on/off toggles ----
        val switchGemini = view.findViewById<SwitchMaterial>(R.id.switchGeminiEnabled)
        val switchOpenRouter = view.findViewById<SwitchMaterial>(R.id.switchOpenRouterEnabled)
        val switchSerp = view.findViewById<SwitchMaterial>(R.id.switchSerpEnabled)
        switchGemini.isChecked = prefs.getBoolean("gemini_enabled", true)
        switchOpenRouter.isChecked = prefs.getBoolean("openrouter_enabled", true)
        switchSerp.isChecked = prefs.getBoolean("serp_enabled", true)
        switchGemini.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("gemini_enabled", checked).apply()
        }
        switchOpenRouter.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("openrouter_enabled", checked).apply()
        }
        switchSerp.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("serp_enabled", checked).apply()
        }

        // ---- Web search switch ----
        val webSwitch = view.findViewById<SwitchMaterial>(R.id.switchWebSearch)
        webSwitch.isChecked = prefs.getBoolean("web_search", false)
        webSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("web_search", checked).apply()
        }

        // ---- Personality / Voice / Language / Avatar rows ----
        updatePersonalityRow(view)
        updateVoiceRow(view)
        updateLanguageRow(view)
        updateAvatarRow(view)
        view.findViewById<View>(R.id.rowPersonality).setOnClickListener { showPersonalityDialog() }
        view.findViewById<View>(R.id.rowVoice).setOnClickListener { showVoiceDialog() }
        view.findViewById<View>(R.id.rowLanguage).setOnClickListener { showLanguageDialog() }
        view.findViewById<View>(R.id.rowAvatar).setOnClickListener { showAvatarDialog() }

        // ---- Voice reply switch + clear chat ----
        val voiceSwitch = view.findViewById<SwitchMaterial>(R.id.switchVoice)
        voiceSwitch.isChecked = prefs.getBoolean("voice_reply", true)
        voiceSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("voice_reply", checked).apply()
        }

        view.findViewById<Button>(R.id.btnClearChat).setOnClickListener {
            ChatStore.messages.clear()
            Toast.makeText(requireContext(), getString(R.string.chat_cleared), Toast.LENGTH_SHORT).show()
        }

        // ---- Permissions section ----
        view.findViewById<Button>(R.id.btnGrantAll).setOnClickListener { grantAllRuntimePermissions() }
        buildPermissions(view.findViewById(R.id.permsContainer))
        refreshPermBadges()
    }

    override fun onResume() {
        super.onResume()
        refreshPermBadges()
    }

    private fun toastSaved() {
        Toast.makeText(requireContext(), getString(R.string.key_saved), Toast.LENGTH_SHORT).show()
    }

    // ---------- Personality ----------

    private fun updatePersonalityRow(root: View? = null) {
        val v = root ?: view ?: return
        v.findViewById<TextView>(R.id.textPersonalityValue).text =
            prefs.getString("personality_name", DEFAULT_PERSONALITY) ?: DEFAULT_PERSONALITY
    }

    private fun showPersonalityDialog() {
        val names = PERSONALITIES.toTypedArray()
        val current = prefs.getString("personality_name", DEFAULT_PERSONALITY) ?: DEFAULT_PERSONALITY
        var checked = PERSONALITIES.indexOf(current).takeIf { it >= 0 }
            ?: PERSONALITIES.indexOf(DEFAULT_PERSONALITY)
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.personality_dialog_title)
            .setSingleChoiceItems(names, checked) { _, which -> checked = which }
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val picked = PERSONALITIES[checked]
                if (picked == "Custom") showCustomPersonalityDialog()
                else {
                    prefs.edit().putString("personality_name", picked).apply()
                    updatePersonalityRow()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showCustomPersonalityDialog() {
        val input = EditText(requireContext()).apply {
            hint = getString(R.string.custom_personality_hint)
            setText(prefs.getString("custom_personality", "").orEmpty())
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.custom_personality_label)
            .setView(input)
            .setPositiveButton(R.string.save) { _, _ ->
                prefs.edit()
                    .putString("personality_name", "Custom")
                    .putString("custom_personality", input.text.toString().trim())
                    .apply()
                updatePersonalityRow()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---------- Voice ----------

    private fun updateVoiceRow(root: View? = null) {
        val v = root ?: view ?: return
        v.findViewById<TextView>(R.id.textVoiceValue).text =
            prefs.getString("tts_voice_name", DEFAULT_VOICE) ?: DEFAULT_VOICE
    }

    private fun showVoiceDialog() {
        val names = VOICES.toTypedArray()
        val current = prefs.getString("tts_voice_name", DEFAULT_VOICE) ?: DEFAULT_VOICE
        var checked = VOICES.indexOf(current).takeIf { it >= 0 } ?: VOICES.indexOf(DEFAULT_VOICE)
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.voice_dialog_title)
            .setSingleChoiceItems(names, checked) { _, which -> checked = which }
            .setPositiveButton(android.R.string.ok) { _, _ ->
                prefs.edit().putString("tts_voice_name", VOICES[checked]).apply()
                updateVoiceRow()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---------- Language ----------

    private fun updateLanguageRow(root: View? = null) {
        val v = root ?: view ?: return
        v.findViewById<TextView>(R.id.textLanguageValue).text =
            prefs.getString("reply_language", DEFAULT_LANGUAGE) ?: DEFAULT_LANGUAGE
    }

    private fun showLanguageDialog() {
        val allNames = listOf(ALL_LANGUAGES) + LANGUAGES
        val names = allNames.toTypedArray()
        val current = prefs.getString("reply_language", DEFAULT_LANGUAGE) ?: DEFAULT_LANGUAGE
        var checked = allNames.indexOf(current).takeIf { it >= 0 } ?: allNames.indexOf(DEFAULT_LANGUAGE)
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.language_dialog_title)
            .setSingleChoiceItems(names, checked) { _, which -> checked = which }
            .setPositiveButton(android.R.string.ok) { _, _ ->
                prefs.edit().putString("reply_language", allNames[checked]).apply()
                updateLanguageRow()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---------- Avatar ----------

    private fun updateAvatarRow(root: View? = null) {
        val v = root ?: view ?: return
        v.findViewById<TextView>(R.id.textAvatarValue).text =
            prefs.getString("avatar_emoji", DEFAULT_AVATAR) ?: DEFAULT_AVATAR
    }

    private fun showAvatarDialog() {
        val names = AVATARS.toTypedArray()
        val current = prefs.getString("avatar_emoji", DEFAULT_AVATAR) ?: DEFAULT_AVATAR
        var checked = AVATARS.indexOf(current).takeIf { it >= 0 } ?: 0
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.avatar_dialog_title)
            .setSingleChoiceItems(names, checked) { _, which -> checked = which }
            .setPositiveButton(android.R.string.ok) { _, _ ->
                prefs.edit().putString("avatar_emoji", AVATARS[checked]).apply()
                updateAvatarRow()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---------- Permissions ----------

    private fun hasRuntimePerm(perm: String): Boolean =
        ContextCompat.checkSelfPermission(requireContext(), perm) ==
                PackageManager.PERMISSION_GRANTED

    private fun permAssistant() = PermRow(
        R.string.perm_assistant, R.string.perm_assistant_desc,
        check = { false },
        action = {
            try {
                startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            } catch (_: Exception) {
            }
        },
        badgeOverride = getString(R.string.perm_action_required)
    )

    private fun permMic() = PermRow(
        R.string.perm_mic, R.string.perm_mic_desc,
        check = { hasRuntimePerm(Manifest.permission.RECORD_AUDIO) },
        action = { requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }
    )

    private fun permOverlay() = PermRow(
        R.string.perm_overlay, R.string.perm_overlay_desc,
        check = {
            try {
                Settings.canDrawOverlays(requireContext())
            } catch (_: Exception) {
                false
            }
        },
        action = {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${requireContext().packageName}")
                    )
                )
            } catch (_: Exception) {
            }
        }
    )

    private fun permNotif() = PermRow(
        R.string.perm_notif, R.string.perm_notif_desc,
        check = {
            if (Build.VERSION.SDK_INT >= 33) hasRuntimePerm(Manifest.permission.POST_NOTIFICATIONS)
            else true
        },
        action = {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    )

    private fun permLocation() = PermRow(
        R.string.perm_location, R.string.perm_location_desc,
        check = { hasRuntimePerm(Manifest.permission.ACCESS_FINE_LOCATION) },
        action = { requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION) }
    )

    private fun permCapture() = PermRow(
        R.string.perm_capture, R.string.perm_capture_desc,
        check = { prefs.getBoolean("screen_capture_granted", false) },
        action = {
            try {
                val mpm = requireContext()
                    .getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                screenCaptureLauncher.launch(mpm.createScreenCaptureIntent())
            } catch (_: Exception) {
            }
        }
    )

    private fun permCamera() = PermRow(
        R.string.perm_camera, R.string.perm_camera_desc,
        check = { hasRuntimePerm(Manifest.permission.CAMERA) },
        action = { requestPermissionLauncher.launch(Manifest.permission.CAMERA) }
    )

    private fun buildPermissions(container: LinearLayout) {
        container.removeAllViews()
        permRowViews.clear()
        val sections = listOf(
            getString(R.string.perm_core) to listOf(permAssistant(), permMic()),
            getString(R.string.perm_system) to listOf(permOverlay(), permNotif()),
            getString(R.string.perm_device) to listOf(permLocation()),
            getString(R.string.perm_media) to listOf(permCapture(), permCamera())
        )
        for ((header, rows) in sections) {
            val headerView = TextView(requireContext()).apply {
                text = header
                setTextColor(ContextCompat.getColor(requireContext(), R.color.neon_blue))
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, 32, 0, 0)
            }
            container.addView(headerView)
            for (row in rows) {
                val item = layoutInflater.inflate(R.layout.item_permission, container, false)
                item.findViewById<TextView>(R.id.permTitle).text = getString(row.titleRes)
                item.findViewById<TextView>(R.id.permDesc).text = getString(row.descRes)
                val badge = item.findViewById<TextView>(R.id.permBadge)
                item.setOnClickListener { row.action() }
                container.addView(item)
                permRowViews.add(PermRowView(row, badge))
            }
        }
    }

    private fun refreshPermBadges() {
        if (!isAdded) return
        for (rv in permRowViews) {
            val granted = try {
                rv.row.check()
            } catch (_: Exception) {
                false
            }
            when {
                rv.row.badgeOverride != null -> {
                    rv.badge.text = rv.row.badgeOverride
                    rv.badge.setBackgroundResource(R.drawable.badge_pink)
                }
                granted -> {
                    rv.badge.text = getString(R.string.perm_granted)
                    rv.badge.setBackgroundResource(R.drawable.badge_green)
                }
                else -> {
                    rv.badge.text = getString(R.string.perm_tap_allow)
                    rv.badge.setBackgroundResource(R.drawable.badge_pink)
                }
            }
        }
    }

    private fun grantAllRuntimePermissions() {
        val needed = mutableListOf<String>()
        if (!hasRuntimePerm(Manifest.permission.RECORD_AUDIO)) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            !hasRuntimePerm(Manifest.permission.POST_NOTIFICATIONS)
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (!hasRuntimePerm(Manifest.permission.ACCESS_FINE_LOCATION)) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (!hasRuntimePerm(Manifest.permission.CAMERA)) {
            needed.add(Manifest.permission.CAMERA)
        }
        if (needed.isNotEmpty()) {
            requestMultipleLauncher.launch(needed.toTypedArray())
        } else {
            Toast.makeText(
                requireContext(),
                getString(R.string.perm_all_granted),
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
