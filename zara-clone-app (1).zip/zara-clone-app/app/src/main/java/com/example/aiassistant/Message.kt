package com.example.aiassistant

/** One chat message. isTyping=true marks the "AI is thinking…" placeholder bubble. */
data class Message(
    val text: String,
    val isUser: Boolean,
    val isTyping: Boolean = false,
    val time: String = ""
)

/** Simple shared in-memory chat history so Settings' "Clear Chat" works across fragments. */
object ChatStore {
    val messages = mutableListOf<Message>()
}
