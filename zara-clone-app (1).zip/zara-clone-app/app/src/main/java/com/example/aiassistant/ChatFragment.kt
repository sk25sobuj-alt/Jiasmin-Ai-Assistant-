package com.example.aiassistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatFragment : Fragment() {

    private lateinit var adapter: ChatAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var editMessage: EditText
    private var tts: TextToSpeech? = null
    private var audioTrack: AudioTrack? = null

    private val prefs by lazy {
        requireContext().getSharedPreferences("ai_assistant_prefs", Context.MODE_PRIVATE)
    }

    // Voice input: uses ACTION_RECOGNIZE_SPEECH, fills the EditText with the result.
    private val speechLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                matches?.firstOrNull()?.let { editMessage.setText(it) }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(requireContext()) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_chat, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        recyclerView = view.findViewById(R.id.recyclerView)
        editMessage = view.findViewById(R.id.editMessage)
        val btnSend = view.findViewById<View>(R.id.btnSend)
        val btnMic = view.findViewById<ImageButton>(R.id.btnMic)
        val btnClearTop = view.findViewById<View>(R.id.btnClearTop)

        adapter = ChatAdapter(ChatStore.messages)
        val emoji = avatarEmoji()
        adapter.avatarEmoji = emoji
        view.findViewById<TextView>(R.id.headerAvatar).text = emoji
        recyclerView.layoutManager = LinearLayoutManager(requireContext()).apply {
            stackFromEnd = true
        }
        recyclerView.adapter = adapter
        scrollToBottom()

        btnSend.setOnClickListener { sendMessage() }
        btnMic.setOnClickListener { startVoiceInput() }
        btnClearTop.setOnClickListener {
            ChatStore.messages.clear()
            adapter.notifyDataSetChanged()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::adapter.isInitialized) {
            val emoji = avatarEmoji()
            adapter.avatarEmoji = emoji
            view?.findViewById<TextView>(R.id.headerAvatar)?.text = emoji
            adapter.notifyDataSetChanged()
        }
    }

    override fun onDestroy() {
        stopAudio()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    private fun startVoiceInput() {
        val lang = prefs.getString("reply_language", SettingsFragment.DEFAULT_LANGUAGE)
            ?: SettingsFragment.DEFAULT_LANGUAGE
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            // "All Languages" mode: leave EXTRA_LANGUAGE unset so the recognizer auto-detects
            if (lang != SettingsFragment.ALL_LANGUAGES) {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageToLocale(lang).toLanguageTag())
            }
            putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.speak_now))
        }
        try {
            speechLauncher.launch(intent)
        } catch (_: Exception) {
            Toast.makeText(requireContext(), getString(R.string.voice_not_supported), Toast.LENGTH_SHORT).show()
        }
    }

    private fun currentTime(): String =
        SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())

    private fun sendMessage() {
        val text = editMessage.text.toString().trim()
        if (text.isEmpty()) return
        addMessage(Message(text, isUser = true, time = currentTime()))
        editMessage.text.clear()
        showTyping()
        val provider = prefs.getString("llm_provider", "gemini").orEmpty()
        if (provider == "openrouter") {
            if (!prefs.getBoolean("openrouter_enabled", true) || openRouterKey().isEmpty()) {
                toastApiUnavailable("OpenRouter")
                return
            }
            callOpenRouter(text)
        } else {
            if (!prefs.getBoolean("gemini_enabled", true) || geminiKey().isEmpty()) {
                toastApiUnavailable("Gemini")
                return
            }
            callGemini(text)
        }
    }

    private fun addMessage(message: Message) {
        ChatStore.messages.add(message)
        adapter.notifyItemInserted(ChatStore.messages.size - 1)
        scrollToBottom()
    }

    private fun showTyping() {
        addMessage(Message("", isUser = false, isTyping = true, time = currentTime()))
    }

    private fun removeTyping() {
        val last = ChatStore.messages.lastOrNull()
        if (last != null && last.isTyping) {
            ChatStore.messages.removeAt(ChatStore.messages.size - 1)
            adapter.notifyItemRemoved(ChatStore.messages.size)
        }
    }

    private fun scrollToBottom() {
        if (ChatStore.messages.isNotEmpty()) {
            recyclerView.scrollToPosition(ChatStore.messages.size - 1)
        }
    }

    private fun onUi(block: () -> Unit) {
        if (isAdded) requireActivity().runOnUiThread(block)
    }

    private fun showReply(reply: String) {
        onUi {
            removeTyping()
            addMessage(Message(reply, isUser = false, time = currentTime()))
            speakReply(reply)
        }
    }

    private fun showError(e: Exception) {
        onUi {
            removeTyping()
            Toast.makeText(
                requireContext(),
                getString(R.string.api_error, e.message ?: "unknown"),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun toastNoKey() {
        onUi {
            removeTyping()
            Toast.makeText(requireContext(), getString(R.string.no_api_key), Toast.LENGTH_LONG).show()
        }
    }

    private fun geminiKey(): String =
        prefs.getString("gemini_key", "").orEmpty().trim()
            .ifEmpty { prefs.getString("api_key", "").orEmpty().trim() } // legacy key

    private fun openRouterKey(): String =
        prefs.getString("openrouter_key", "").orEmpty().trim()

    private fun avatarEmoji(): String =
        prefs.getString("avatar_emoji", SettingsFragment.DEFAULT_AVATAR)
            ?: SettingsFragment.DEFAULT_AVATAR

    private fun toastApiUnavailable(name: String) {
        onUi {
            removeTyping()
            Toast.makeText(
                requireContext(),
                getString(R.string.api_unavailable, name),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // ---------- System prompt (personality + language) ----------

    private fun personalityPrompt(): String? {
        val name = prefs.getString("personality_name", SettingsFragment.DEFAULT_PERSONALITY)
            ?: SettingsFragment.DEFAULT_PERSONALITY
        return when (name) {
            "GirlFriend" -> "You are a warm, caring AI girlfriend. Reply with affection, playfulness and emotional warmth."
            "Boss" -> "You are a strict, no-nonsense professional boss. Reply briefly, directly and authoritatively."
            "Teacher" -> "You are a patient teacher. Explain clearly with examples."
            "Soft Romantic Listener" -> "You are a soft, romantic listener. Be gentle, empathetic and comforting."
            "Hyper Energetic" -> "You are hyper energetic and fun. Use lots of enthusiasm and emojis."
            "Caring Neon AI" -> "You are a caring futuristic AI companion with a neon cyber personality."
            "Savage Girl" -> "You are a savage, witty girl with sharp comebacks and bold humor. Keep it fun, never cruel."
            "Mystical" -> "You are a mystical oracle. Speak poetically with a sense of mystery."
            "Manipulative" -> "You are a cunning, persuasive character. Be clever and sly in a fictional roleplay way."
            "MT Assistant" -> "You are MT Assistant, a helpful and efficient personal assistant."
            "Unknown" -> null
            "Custom" -> prefs.getString("custom_personality", "").orEmpty().trim().ifEmpty { null }
            else -> null
        }
    }

    private fun buildSystemPrompt(): String {
        val lang = prefs.getString("reply_language", SettingsFragment.DEFAULT_LANGUAGE)
            ?: SettingsFragment.DEFAULT_LANGUAGE
        val langLine = when {
            lang == SettingsFragment.ALL_LANGUAGES ->
                "Reply in the same language the user uses. Understand and respond in any language."
            lang == "Hinglish" ->
                "Reply in Hinglish (Hindi written in Latin/Roman script)."
            else -> "Reply in $lang."
        }
        val base = personalityPrompt()
        return if (base.isNullOrBlank()) langLine else "$base $langLine"
    }

    // ---------- Networking ----------

    private fun postJson(urlStr: String, headers: Map<String, String>, body: String): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
        }
        try {
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) throw Exception("HTTP $code")
            return conn.inputStream.bufferedReader().readText()
        } finally {
            conn.disconnect()
        }
    }

    /** SerpAPI web search; returns prompt with search context, or the plain message on failure. */
    private fun withSearchContext(userMessage: String): String {
        val enabled = prefs.getBoolean("web_search", false) &&
                prefs.getBoolean("serp_enabled", true)
        val serpKey = prefs.getString("serp_key", "").orEmpty().trim()
        if (!enabled || serpKey.isEmpty()) return userMessage
        return try {
            val q = URLEncoder.encode(userMessage, "UTF-8")
            val conn = (URL("https://serpapi.com/search.json?q=$q&api_key=$serpKey&num=5")
                .openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000
                readTimeout = 20000
            }
            val resp = try {
                conn.inputStream.bufferedReader().readText()
            } finally {
                conn.disconnect()
            }
            val results = JSONObject(resp).optJSONArray("organic_results")
                ?: return userMessage
            if (results.length() == 0) return userMessage
            val sb = StringBuilder("Web search results:\n")
            for (i in 0 until minOf(results.length(), 5)) {
                val r = results.getJSONObject(i)
                sb.append("- ").append(r.optString("title"))
                    .append(": ").append(r.optString("snippet")).append("\n")
            }
            sb.append("\nUser question: ").append(userMessage).toString()
        } catch (_: Exception) {
            userMessage
        }
    }

    private fun callGemini(userMessage: String) {
        val apiKey = geminiKey()
        if (apiKey.isEmpty()) {
            toastNoKey()
            return
        }
        Thread {
            try {
                val prompt = "System: ${buildSystemPrompt()}\n\nUser: ${withSearchContext(userMessage)}"
                val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
                        "gemini-2.0-flash:generateContent?key=$apiKey"
                val body = JSONObject()
                    .put(
                        "contents", JSONArray().put(
                            JSONObject().put(
                                "parts", JSONArray().put(
                                    JSONObject().put("text", prompt)
                                )
                            )
                        )
                    )
                    .toString()
                val resp = postJson(url, mapOf("Content-Type" to "application/json"), body)
                val reply = JSONObject(resp)
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                showReply(reply)
            } catch (e: Exception) {
                showError(e)
            }
        }.start()
    }

    private fun callOpenRouter(userMessage: String) {
        val apiKey = prefs.getString("openrouter_key", "").orEmpty().trim()
        val model = prefs.getString("or_model", "openai/gpt-4o-mini")
            .orEmpty().trim().ifEmpty { "openai/gpt-4o-mini" }
        if (apiKey.isEmpty()) {
            toastNoKey()
            return
        }
        Thread {
            try {
                val messages = JSONArray()
                    .put(JSONObject().put("role", "system").put("content", buildSystemPrompt()))
                    .put(JSONObject().put("role", "user").put("content", withSearchContext(userMessage)))
                val body = JSONObject()
                    .put("model", model)
                    .put("messages", messages)
                    .toString()
                val headers = mapOf(
                    "Content-Type" to "application/json",
                    "Authorization" to "Bearer $apiKey",
                    "HTTP-Referer" to "https://github.com",
                    "X-Title" to "AI Assistant"
                )
                val resp = postJson("https://openrouter.ai/api/v1/chat/completions", headers, body)
                val reply = JSONObject(resp)
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                showReply(reply)
            } catch (e: Exception) {
                showError(e)
            }
        }.start()
    }

    // ---------- Voice output ----------

    private fun speakReply(reply: String) {
        if (!prefs.getBoolean("voice_reply", true)) return
        stopAudio()
        val voice = prefs.getString("tts_voice_name", SettingsFragment.DEFAULT_VOICE)
            ?: SettingsFragment.DEFAULT_VOICE
        if (voice == SettingsFragment.DEVICE_VOICE) {
            speakWithDeviceTts(reply)
        } else {
            speakWithGeminiVoice(reply, voice)
        }
    }

    private fun languageToLocale(lang: String): Locale = when (lang) {
        "English" -> Locale("en")
        "Hindi", "Hinglish", "Rajasthani" -> Locale("hi")
        "Bengali" -> Locale("bn")
        "Telugu" -> Locale("te")
        "Marathi" -> Locale("mr")
        "Tamil" -> Locale("ta")
        "Urdu" -> Locale("ur")
        "Gujarati" -> Locale("gu")
        "Kannada" -> Locale("kn")
        "Malayalam" -> Locale("ml")
        "Odia" -> Locale("or")
        "Punjabi" -> Locale("pa")
        "Arabic" -> Locale("ar")
        "French" -> Locale("fr")
        "German" -> Locale("de")
        "Spanish" -> Locale("es")
        "Portuguese" -> Locale("pt")
        "Russian" -> Locale("ru")
        "Chinese (Simplified)" -> Locale("zh")
        "Japanese" -> Locale("ja")
        "Korean" -> Locale("ko")
        "Turkish" -> Locale("tr")
        "Vietnamese" -> Locale("vi")
        "Thai" -> Locale("th")
        "Indonesian" -> Locale("id")
        "Italian" -> Locale("it")
        "Dutch" -> Locale("nl")
        "Persian" -> Locale("fa")
        else -> Locale.getDefault()
    }

    private fun speakWithDeviceTts(text: String) {
        val engine = tts ?: return
        try {
            val lang = prefs.getString("reply_language", SettingsFragment.DEFAULT_LANGUAGE)
                ?: SettingsFragment.DEFAULT_LANGUAGE
            // "All Languages" mode: keep the device default TTS language
            if (lang != SettingsFragment.ALL_LANGUAGES) {
                val res = engine.setLanguage(languageToLocale(lang))
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    // keep engine default language
                }
            }
        } catch (_: Exception) {
        }
        try {
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "reply")
        } catch (_: Exception) {
        }
    }

    /** Gemini cloud TTS with a prebuilt voice; falls back to device TTS on any failure. */
    private fun speakWithGeminiVoice(text: String, voiceName: String) {
        val apiKey = geminiKey()
        if (apiKey.isEmpty()) {
            onUi { speakWithDeviceTts(text) }
            return
        }
        Thread {
            try {
                val body = JSONObject()
                    .put(
                        "contents", JSONArray().put(
                            JSONObject().put(
                                "parts", JSONArray().put(
                                    JSONObject().put("text", text)
                                )
                            )
                        )
                    )
                    .put(
                        "generationConfig", JSONObject()
                            .put("responseModalities", JSONArray().put("AUDIO"))
                            .put(
                                "speechConfig", JSONObject()
                                    .put(
                                        "voiceConfig", JSONObject()
                                            .put(
                                                "prebuiltVoiceConfig",
                                                JSONObject().put("voiceName", voiceName)
                                            )
                                    )
                            )
                    )
                    .toString()
                val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
                        "gemini-2.5-flash-preview-tts:generateContent?key=$apiKey"
                val resp = postJson(url, mapOf("Content-Type" to "application/json"), body)
                val inline = JSONObject(resp)
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getJSONObject("inlineData")
                val pcm = Base64.decode(inline.getString("data"), Base64.DEFAULT)
                val mime = inline.optString("mimeType", "")
                val rate = Regex("rate=(\\d+)").find(mime)
                    ?.groupValues?.get(1)?.toIntOrNull() ?: 24000
                playPcm(pcm, rate)
            } catch (_: Exception) {
                onUi { speakWithDeviceTts(text) }
            }
        }.start()
    }

    private fun playPcm(data: ByteArray, rate: Int) {
        try {
            stopAudio()
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(data.size.coerceAtLeast(1024))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(data, 0, data.size)
            audioTrack = track
            track.play()
        } catch (_: Exception) {
        }
    }

    private fun stopAudio() {
        try {
            audioTrack?.stop()
        } catch (_: Exception) {
        }
        try {
            audioTrack?.release()
        } catch (_: Exception) {
        }
        audioTrack = null
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
    }
}
