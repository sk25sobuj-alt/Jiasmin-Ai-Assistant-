package com.example.aiassistant

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChatAdapter(private val messages: MutableList<Message>) :
    RecyclerView.Adapter<ChatAdapter.ViewHolder>() {

    var avatarEmoji: String = "🤖"

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val avatar: TextView = view.findViewById(R.id.avatarEmoji)
        val bubbleAi: LinearLayout = view.findViewById(R.id.bubbleAi)
        val bubbleUser: LinearLayout = view.findViewById(R.id.bubbleUser)
        val aiText: TextView = view.findViewById(R.id.textAi)
        val userText: TextView = view.findViewById(R.id.textUser)
        val aiTime: TextView = view.findViewById(R.id.textAiTime)
        val userTime: TextView = view.findViewById(R.id.textUserTime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_message, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val msg = messages[position]
        if (msg.isUser) {
            holder.bubbleAi.visibility = View.GONE
            holder.bubbleUser.visibility = View.VISIBLE
            holder.userText.text = msg.text
            holder.userTime.text = "✓✓ ${msg.time}"
        } else {
            holder.bubbleUser.visibility = View.GONE
            holder.bubbleAi.visibility = View.VISIBLE
            holder.aiText.text = if (msg.isTyping) "…" else msg.text
            holder.aiTime.text = msg.time
            holder.avatar.text = avatarEmoji
        }
    }

    override fun getItemCount(): Int = messages.size
}
